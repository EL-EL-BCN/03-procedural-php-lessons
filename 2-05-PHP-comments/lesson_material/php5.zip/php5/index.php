<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php
      //This is a one line comment

      /*This is a comment
      chunk which can be
      on multiple lines*/
    ?>
  </body>
</html>
